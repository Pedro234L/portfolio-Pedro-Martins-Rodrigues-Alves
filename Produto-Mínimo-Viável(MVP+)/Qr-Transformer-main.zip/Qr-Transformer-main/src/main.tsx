import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { AuthProvider } from './context/AuthContext';
import { ColorBlindProvider } from './context/ColorBlindContext';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider>
      <ColorBlindProvider>
        <App />
      </ColorBlindProvider>
    </AuthProvider>
  </StrictMode>,
);
