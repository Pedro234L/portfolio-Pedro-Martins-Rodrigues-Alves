import { Options, DotType, GradientType, CornerSquareType, CornerDotType } from 'qr-code-styling';

export type DotStyle = DotType;
export type CornerSquareStyle = CornerSquareType;
export type CornerDotStyle = CornerDotType;

export interface QRState {
  data: string;
  image: string | null;
  width: number;
  height: number;
  margin: number;
  dotsOptions: {
    type: DotStyle;
    colorType: 'single' | 'gradient';
    gradient: {
      type: GradientType;
      rotation: number;
      colorStops: { offset: number; color: string }[];
    };
    color: string;
  };
  cornersSquareOptions: {
    type: CornerSquareStyle;
    colorType: 'single' | 'gradient';
    gradient: {
      type: GradientType;
      rotation: number;
      colorStops: { offset: number; color: string }[];
    };
    color: string;
  };
  cornersDotOptions: {
    type: CornerDotStyle;
    colorType: 'single' | 'gradient';
    gradient: {
      type: GradientType;
      rotation: number;
      colorStops: { offset: number; color: string }[];
    };
    color: string;
  };
  backgroundOptions: {
    colorType: 'single' | 'gradient';
    gradient: {
      type: GradientType;
      rotation: number;
      colorStops: { offset: number; color: string }[];
    };
    color: string;
  };
  imageOptions: {
    hideBackgroundDots: boolean;
    imageSize: number;
    margin: number;
  };
  qrOptions: {
    typeNumber: number;
    mode: 'Numeric' | 'Alphanumeric' | 'Byte' | 'Kanji';
    errorCorrectionLevel: 'L' | 'M' | 'Q' | 'H';
  };
}

export const initialQRState: QRState = {
  data: 'https://ais-dev-sgfnaqahdp5akxj2zkpi6t-429754049107.us-west2.run.app',
  image: null,
  width: 300,
  height: 300,
  margin: 0,
  dotsOptions: {
    type: 'square',
    colorType: 'single',
    gradient: {
      type: 'linear',
      rotation: 0,
      colorStops: [
        { offset: 0, color: '#000000' },
        { offset: 1, color: '#000000' },
      ],
    },
    color: '#000000',
  },
  cornersSquareOptions: {
    type: 'square',
    colorType: 'single',
    gradient: {
      type: 'linear',
      rotation: 0,
      colorStops: [
        { offset: 0, color: '#000000' },
        { offset: 1, color: '#000000' },
      ],
    },
    color: '#000000',
  },
  cornersDotOptions: {
    type: 'square',
    colorType: 'single',
    gradient: {
      type: 'linear',
      rotation: 0,
      colorStops: [
        { offset: 0, color: '#000000' },
        { offset: 1, color: '#000000' },
      ],
    },
    color: '#000000',
  },
  backgroundOptions: {
    colorType: 'single',
    gradient: {
      type: 'linear',
      rotation: 0,
      colorStops: [
        { offset: 0, color: '#ffffff' },
        { offset: 1, color: '#ffffff' },
      ],
    },
    color: '#ffffff',
  },
  imageOptions: {
    hideBackgroundDots: true,
    imageSize: 0.4,
    margin: 0,
  },
  qrOptions: {
    typeNumber: 0,
    mode: 'Byte',
    errorCorrectionLevel: 'Q',
  },
};
