import { 
  collection, 
  addDoc, 
  query, 
  where, 
  getDocs, 
  deleteDoc, 
  doc, 
  serverTimestamp,
  orderBy,
  limit
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { QRState } from '../types/qr';

export const saveQRConfig = async (userId: string, name: string, config: QRState) => {
  try {
    const docRef = await addDoc(collection(db, 'qrConfigs'), {
      userId,
      name,
      config,
      createdAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    console.error("Error saving QR config:", error);
    throw error;
  }
};

export const getQRConfigs = async (userId: string) => {
  try {
    const q = query(
      collection(db, 'qrConfigs'), 
      where('userId', '==', userId),
      orderBy('createdAt', 'desc'),
      limit(20)
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as { id: string, name: string, config: QRState, createdAt: any }[];
  } catch (error) {
    console.error("Error getting QR configs:", error);
    throw error;
  }
};

export const savePublicTemplate = async (userId: string, userName: string, templateName: string, config: QRState) => {
  try {
    const docRef = await addDoc(collection(db, 'communityTemplates'), {
      userId,
      userName,
      name: templateName,
      config,
      createdAt: serverTimestamp(),
      likes: 0
    });
    return docRef.id;
  } catch (error) {
    console.error("Error saving public template:", error);
    throw error;
  }
};

export const getPublicTemplates = async () => {
  try {
    const q = query(
      collection(db, 'communityTemplates'),
      orderBy('createdAt', 'desc'),
      limit(24)
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as { id: string, name: string, userName: string, config: QRState, createdAt: any, likes: number }[];
  } catch (error) {
    console.error("Error getting public templates:", error);
    throw error;
  }
};

export const deleteQRConfig = async (configId: string) => {
  try {
    await deleteDoc(doc(db, 'qrConfigs', configId));
  } catch (error) {
    console.error("Error deleting QR config:", error);
    throw error;
  }
};
