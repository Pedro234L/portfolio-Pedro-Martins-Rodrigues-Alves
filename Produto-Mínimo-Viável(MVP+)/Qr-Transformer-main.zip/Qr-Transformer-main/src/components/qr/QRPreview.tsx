import React, { useEffect, useRef } from 'react';
import QRCodeStyling from 'qr-code-styling';
import { QRState } from '../../types/qr';

interface QRPreviewProps {
  options: QRState;
}

export const QRPreview: React.FC<QRPreviewProps> = ({ options }) => {
  const ref = useRef<HTMLDivElement>(null);
  const qrCode = useRef<QRCodeStyling>(new QRCodeStyling({
    width: options.width,
    height: options.height,
    data: options.data,
    margin: options.margin,
    image: options.image || undefined,
    dotsOptions: {
      type: options.dotsOptions.type,
      color: options.dotsOptions.colorType === 'single' ? options.dotsOptions.color : undefined,
      gradient: options.dotsOptions.colorType === 'gradient' ? {
        type: options.dotsOptions.gradient.type,
        rotation: (options.dotsOptions.gradient.rotation * Math.PI) / 180,
        colorStops: options.dotsOptions.gradient.colorStops
      } : undefined
    }
  }));

  useEffect(() => {
    if (ref.current) {
      qrCode.current.append(ref.current);
    }
  }, []);

  useEffect(() => {
    qrCode.current.update({
      width: options.width,
      height: options.height,
      data: options.data,
      margin: options.margin,
      image: options.image || undefined,
      dotsOptions: {
        type: options.dotsOptions.type,
        color: options.dotsOptions.colorType === 'single' ? options.dotsOptions.color : undefined,
        gradient: options.dotsOptions.colorType === 'gradient' ? {
          type: options.dotsOptions.gradient.type,
          rotation: (options.dotsOptions.gradient.rotation * Math.PI) / 180,
          colorStops: options.dotsOptions.gradient.colorStops
        } : undefined
      },
      cornersSquareOptions: {
        type: options.cornersSquareOptions.type || undefined,
        color: options.cornersSquareOptions.colorType === 'single' ? options.cornersSquareOptions.color : undefined,
        gradient: options.cornersSquareOptions.colorType === 'gradient' ? {
          type: options.cornersSquareOptions.gradient.type,
          rotation: (options.cornersSquareOptions.gradient.rotation * Math.PI) / 180,
          colorStops: options.cornersSquareOptions.gradient.colorStops
        } : undefined
      },
      cornersDotOptions: {
        type: options.cornersDotOptions.type || undefined,
        color: options.cornersDotOptions.colorType === 'single' ? options.cornersDotOptions.color : undefined,
        gradient: options.cornersDotOptions.colorType === 'gradient' ? {
          type: options.cornersDotOptions.gradient.type,
          rotation: (options.cornersDotOptions.gradient.rotation * Math.PI) / 180,
          colorStops: options.cornersDotOptions.gradient.colorStops
        } : undefined
      },
      backgroundOptions: {
        color: options.backgroundOptions.colorType === 'single' ? options.backgroundOptions.color : undefined,
        gradient: options.backgroundOptions.colorType === 'gradient' ? {
          type: options.backgroundOptions.gradient.type,
          rotation: (options.backgroundOptions.gradient.rotation * Math.PI) / 180,
          colorStops: options.backgroundOptions.gradient.colorStops
        } : undefined
      },
      imageOptions: {
        hideBackgroundDots: options.imageOptions.hideBackgroundDots,
        imageSize: options.imageOptions.imageSize,
        margin: options.imageOptions.margin
      },
      qrOptions: {
        typeNumber: options.qrOptions.typeNumber,
        mode: options.qrOptions.mode,
        errorCorrectionLevel: options.qrOptions.errorCorrectionLevel
      }
    });
  }, [options]);

  const onDownload = (extension: 'png' | 'svg') => {
    qrCode.current.download({ extension });
  };

  return (
    <div className="flex flex-col items-center gap-8 w-full">
      <div 
        className="relative p-8 rounded-2xl bg-white border border-slate-200 shadow-xl overflow-hidden group focus-within:ring-2 focus-within:ring-slate-900 focus-within:ring-offset-2 transition-all outline-none"
        role="region"
        aria-label="Visualização do QR Code gerado"
      >
        <div className="absolute inset-0 bg-slate-50 pointer-events-none opacity-50" />
        <div 
          ref={ref} 
          className="bg-white rounded-lg shadow-sm border border-slate-100 z-10 relative" 
          role="img" 
          aria-label={`QR Code dinâmico com o conteúdo: ${options.data}`}
        />
        <div className="absolute top-3 right-3 bg-emerald-500 h-2.5 w-2.5 rounded-full" aria-hidden="true" />
      </div>
      
      <div className="flex flex-col gap-3 w-full">
        <button 
          onClick={() => onDownload('png')}
          className="w-full bg-slate-900 text-white py-4 rounded-xl hover:bg-slate-800 active:scale-[0.98] shadow-md transition-all font-extrabold uppercase tracking-widest text-[11px] focus-visible:ring-4 focus-visible:ring-slate-900/20 focus-visible:outline-none"
        >
          Baixar .PNG
        </button>
        <button 
          onClick={() => onDownload('svg')}
          className="w-full border-2 border-slate-900 text-slate-900 py-4 rounded-xl hover:bg-slate-50 active:scale-[0.98] transition-all font-extrabold uppercase tracking-widest text-[11px] focus-visible:ring-4 focus-visible:ring-slate-900/20 focus-visible:outline-none"
        >
          Exportar .SVG (Vetor)
        </button>
      </div>

      <div className="w-full flex items-center justify-between px-2 pt-6 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Pronto para uso</span>
        </div>
        <span className="text-[10px] font-mono text-slate-400">ESTÁVEL v3.0</span>
      </div>
    </div>
  );
};
