import React, { useState, useEffect } from 'react';
import { cn } from '../../lib/utils';
import { QRState, DotStyle, CornerSquareStyle, CornerDotStyle } from '../../types/qr';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Button, buttonVariants } from '../ui/button';
import { Tabs, TabsList, TabsTrigger } from '../ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '../ui/accordion';
import { 
  ImagePlus, 
  Trash2, 
  Eye, 
  EyeOff, 
  FileJson, 
  Settings2, 
  Palette, 
  Square, 
  CircleDot, 
  Image as ImageIcon, 
  QrCode, 
  Save, 
  Cloud, 
  ChevronRight,
  History,
  Loader2
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { saveQRConfig, getQRConfigs, deleteQRConfig } from '../../services/qrService';
import { toast } from 'sonner';

interface QRControlsProps {
  options: QRState;
  setOptions: React.Dispatch<React.SetStateAction<QRState>>;
}

export const QRControls: React.FC<QRControlsProps> = ({ options, setOptions }) => {
  const { user } = useAuth();
  const [savedConfigs, setSavedConfigs] = useState<any[]>([]);
  const [configName, setConfigName] = useState('Nova Estilização');
  const [isSaving, setIsSaving] = useState(false);
  const [isLoadingConfigs, setIsLoadingConfigs] = useState(false);

  useEffect(() => {
    if (user) {
      loadConfigs();
    }
  }, [user]);

  const loadConfigs = async () => {
    if (!user) return;
    setIsLoadingConfigs(true);
    try {
      const configs = await getQRConfigs(user.uid);
      setSavedConfigs(configs);
    } catch (error) {
      toast.error("Erro ao carregar configurações");
    } finally {
      setIsLoadingConfigs(false);
    }
  };

  const handleSave = async () => {
    if (!user) {
      toast.error("Faça login para salvar");
      return;
    }
    setIsSaving(true);
    try {
      await saveQRConfig(user.uid, configName, options);
      toast.success("Configuração salva na nuvem!");
      loadConfigs();
    } catch (error) {
      toast.error("Erro ao salvar configuração");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteConfig = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    try {
      await deleteQRConfig(id);
      setSavedConfigs(prev => prev.filter(c => c.id !== id));
      toast.success("Configuração excluída");
    } catch (error) {
      toast.error("Erro ao excluir");
    }
  };
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setOptions(prev => ({ ...prev, image: event.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const updateSection = (section: keyof QRState, updates: any) => {
    setOptions(prev => ({
      ...prev,
      [section]: { ...(prev[section] as object), ...updates }
    }));
  };

  const updateGradient = (section: keyof QRState, updates: any) => {
    setOptions(prev => ({
      ...prev,
      [section]: {
        ...(prev[section] as any),
        gradient: { ...(prev[section] as any).gradient, ...updates }
      }
    }));
  };

  const exportAsJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(options, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "qr-config.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const ColorControls = ({ section, config, label = "Coloração" }: { section: keyof QRState, config: any, label?: string }) => (
    <div className="space-y-4" role="group" aria-labelledby={`${section}-label`}>
      <div className="space-y-2">
        <Label id={`${section}-label`} className="text-[11px] uppercase text-slate-900 font-extrabold tracking-widest">{label}</Label>
        <Tabs 
          value={config.colorType} 
          onValueChange={(val) => updateSection(section, { colorType: val })}
          className="bg-slate-100 p-1 rounded-lg"
        >
          <TabsList className="w-full bg-transparent">
            <TabsTrigger 
              value="single" 
              className="flex-1 text-[10px] uppercase font-bold data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=active]:shadow-sm focus-visible:ring-2 focus-visible:ring-slate-900"
              aria-label="Cor única"
            >
              Sólido
            </TabsTrigger>
            <TabsTrigger 
              value="gradient" 
              className="flex-1 text-[10px] uppercase font-bold data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=active]:shadow-sm focus-visible:ring-2 focus-visible:ring-slate-900"
              aria-label="Gradiente de cores"
            >
              Gradiente
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {config.colorType === 'single' ? (
        <div className="space-y-2">
          <div className="flex gap-3 items-center">
            <div className="relative group/color">
              <Input 
                type="color" 
                aria-label={`Selecionar cor para ${label}`}
                className="w-12 h-12 p-1 cursor-pointer bg-white border-slate-200 rounded-lg focus:ring-2 focus:ring-slate-900 transition-all" 
                value={config.color}
                onChange={(e) => updateSection(section, { color: e.target.value })}
              />
            </div>
            <Input 
              type="text" 
              value={config.color}
              aria-label={`Código Hex da cor para ${label}`}
              onChange={(e) => updateSection(section, { color: e.target.value })}
              className="flex-1 h-12 font-mono text-sm bg-white border-slate-200 text-slate-900 uppercase focus:border-slate-900 focus:ring-0 transition-all"
            />
          </div>
        </div>
      ) : (
        <div className="space-y-4 p-5 bg-slate-50 rounded-xl border border-slate-200" role="region" aria-label={`Configurações de gradiente para ${label}`}>
          <div className="space-y-2">
            <Label className="text-[9px] uppercase tracking-widest text-slate-500 font-bold">Projeção do Campo</Label>
            <Tabs 
              value={config.gradient.type} 
              onValueChange={(val) => updateGradient(section, { type: val })}
              className="bg-white p-1 rounded-md border border-slate-200"
            >
              <TabsList className="w-full bg-transparent h-8">
                <TabsTrigger value="linear" className="flex-1 text-[10px] uppercase">Linear</TabsTrigger>
                <TabsTrigger value="radial" className="flex-1 text-[10px] uppercase">Radial</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-[9px] uppercase tracking-widest text-slate-500 font-bold">Cor A</Label>
              <Input 
                type="color" 
                aria-label="Cor inicial do gradiente"
                className="w-full h-10 p-1 cursor-pointer bg-white border-slate-200 rounded-md focus:ring-2 focus:ring-slate-900 transition-all" 
                value={config.gradient.colorStops[0].color}
                onChange={(e) => {
                  const stops = [...config.gradient.colorStops];
                  stops[0].color = e.target.value;
                  updateGradient(section, { colorStops: stops });
                }}
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[9px] uppercase tracking-widest text-slate-500 font-bold">Cor B</Label>
              <Input 
                type="color" 
                aria-label="Cor final do gradiente"
                className="w-full h-10 p-1 cursor-pointer bg-white border-slate-200 rounded-md focus:ring-2 focus:ring-slate-900 transition-all" 
                value={config.gradient.colorStops[1].color}
                onChange={(e) => {
                  const stops = [...config.gradient.colorStops];
                  stops[1].color = e.target.value;
                  updateGradient(section, { colorStops: stops });
                }}
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label className="text-[9px] uppercase tracking-widest text-slate-500 font-bold">Rotação de Fase</Label>
              <span className="text-[11px] font-bold text-slate-900" aria-live="polite">{config.gradient.rotation}°</span>
            </div>
            <Input 
              type="number" 
              aria-label="Ângulo de rotação do gradiente"
              value={config.gradient.rotation}
              onChange={(e) => updateGradient(section, { rotation: Number(e.target.value) })}
              className="h-10 bg-white border-slate-200 text-sm focus:ring-2 focus:ring-slate-900 transition-all"
            />
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-8">
      {/* 1. Opções Principais - Always Visible */}
      <div className="space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-5">
          <div className="bg-slate-100 p-2 rounded-lg">
            <Settings2 className="w-5 h-5 text-slate-900" />
          </div>
          <h3 className="text-xl font-black uppercase tracking-tighter text-slate-900 underline decoration-emerald-500 decoration-4 underline-offset-4">Configuração Core</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="data" className="text-[11px] font-black uppercase tracking-widest text-slate-900">Dados do QR Code</Label>
            <Input 
              id="data" 
              value={options.data} 
              onChange={(e) => setOptions(prev => ({ ...prev, data: e.target.value }))}
              placeholder="https://exemplo.com"
              className="h-12 bg-white border-slate-200 text-slate-900 focus:border-slate-900 focus:ring-0 transition-all"
            />
          </div>

          <div className="space-y-2 md:col-span-2">
            <Label className="text-[11px] font-black uppercase tracking-widest text-slate-900">Logo Central</Label>
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <Input 
                  type="file" 
                  className="hidden" 
                  id="image-upload" 
                  accept="image/*"
                  onChange={handleImageUpload}
                />
                <label 
                  htmlFor="image-upload"
                  className={cn(
                    buttonVariants({ variant: "outline" }),
                    "w-full h-12 cursor-pointer flex gap-3 bg-white border-slate-200 text-slate-900 hover:bg-slate-50 transition-all font-bold"
                  )}
                >
                  <ImagePlus className="w-5 h-5 text-emerald-600" />
                  Enviar Logotipo
                </label>
              </div>
              {options.image && (
                <Button 
                  variant="destructive" 
                  size="icon"
                  className="h-12 w-12 rounded-lg bg-rose-50 text-rose-600 border border-rose-200 hover:bg-rose-100 transition-all"
                  onClick={() => setOptions(prev => ({ ...prev, image: null }))}
                >
                  <Trash2 className="w-5 h-5" />
                </Button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 md:col-span-2">
            <div className="space-y-2">
              <Label htmlFor="width" className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Largura (px)</Label>
              <Input 
                id="width" 
                type="number" 
                value={options.width} 
                onChange={(e) => setOptions(prev => ({ ...prev, width: Number(e.target.value) }))}
                className="h-10 bg-white border-slate-200 text-slate-900 focus:ring-1 focus:ring-slate-900"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="margin" className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Margem</Label>
              <Input 
                id="margin" 
                type="number" 
                value={options.margin} 
                onChange={(e) => setOptions(prev => ({ ...prev, margin: Number(e.target.value) }))}
                className="h-10 bg-white border-slate-200 text-slate-900 focus:ring-1 focus:ring-slate-900"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Collapsible Sections */}
      <Accordion type="multiple" className="space-y-4">
        {/* 2. Opções de Pontos */}
        <AccordionItem value="dots" className="bg-white border border-slate-100 rounded-xl overflow-hidden px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline py-5 group">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-emerald-50 text-emerald-600 group-hover:bg-emerald-100 transition-colors">
                <Palette className="w-4 h-4" />
              </div>
              <span className="text-xs font-black uppercase tracking-widest text-slate-900">Estilo da Malha</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-6 space-y-6">
            <div className="space-y-3">
              <Label className="text-[10px] uppercase text-slate-400 font-bold">Geometria</Label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {(['square', 'dots', 'rounded', 'extra-rounded', 'classy', 'classy-rounded'] as DotStyle[]).map((style) => (
                  <Button
                    key={style}
                    variant={options.dotsOptions.type === style ? 'default' : 'outline'}
                    className={`text-[9px] font-black uppercase h-9 transition-all ${
                      options.dotsOptions.type === style 
                        ? 'bg-slate-900 text-white shadow-md' 
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                    onClick={() => updateSection('dotsOptions', { type: style })}
                  >
                    {style.replace('-', ' ')}
                  </Button>
                ))}
              </div>
            </div>
            <ColorControls section="dotsOptions" config={options.dotsOptions} label="Cor da Malha" />
          </AccordionContent>
        </AccordionItem>

        {/* 3. Opções de Cantos Quadrados (Moldura) */}
        <AccordionItem value="corners-square" className="bg-white border border-slate-100 rounded-xl overflow-hidden px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline py-5 group">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-slate-100 text-slate-900 group-hover:bg-slate-200 transition-colors">
                <Square className="w-4 h-4" />
              </div>
              <span className="text-xs font-black uppercase tracking-widest text-slate-900">Moldura dos Cantos</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-6 space-y-6">
            <div className="space-y-3">
              <Label className="text-[10px] uppercase text-slate-400 font-bold italic tracking-tighter flex items-center gap-1">
                <div className="w-1 h-1 bg-emerald-500 rounded-full" /> Estilo de Cantos Quadrados
              </Label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {([undefined, 'square', 'dot', 'extra-rounded'] as (CornerSquareStyle | undefined)[]).map((style) => (
                  <Button
                    key={style || 'none'}
                    variant={options.cornersSquareOptions.type === style ? 'default' : 'outline'}
                    className={`text-[8px] font-black uppercase h-9 transition-all ${
                      options.cornersSquareOptions.type === style 
                        ? 'bg-slate-900 text-white shadow-md' 
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                    onClick={() => updateSection('cornersSquareOptions', { type: style })}
                  >
                    {style === undefined ? 'Nenhum' : style === 'dot' ? 'Ponto' : style.replace('-', ' ')}
                  </Button>
                ))}
              </div>
            </div>
            <div className="border border-slate-100 p-4 rounded-xl bg-slate-50/30">
              <ColorControls section="cornersSquareOptions" config={options.cornersSquareOptions} label="Cor da Moldura" />
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* 4. Opções de Pontos nos Cantos (Ponto Interno) */}
        <AccordionItem value="corners-dot" className="bg-white border border-slate-100 rounded-xl overflow-hidden px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline py-5 group">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-blue-50 text-blue-600 group-hover:bg-blue-100 transition-colors">
                <CircleDot className="w-4 h-4" />
              </div>
              <span className="text-xs font-black uppercase tracking-widest text-slate-900">Núcleo dos Cantos</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-6 space-y-6">
            <div className="space-y-3">
              <Label className="text-[10px] uppercase text-slate-400 font-bold italic tracking-tighter flex items-center gap-1">
                <div className="w-1 h-1 bg-blue-500 rounded-full" /> Estilo de Pontos nos Cantos
              </Label>
              <div className="grid grid-cols-3 gap-2">
                {([undefined, 'square', 'dot'] as (CornerDotStyle | undefined)[]).map((style) => (
                  <Button
                    key={style || 'none'}
                    variant={options.cornersDotOptions.type === style ? 'default' : 'outline'}
                    className={`text-[8px] font-black uppercase h-9 transition-all ${
                      options.cornersDotOptions.type === style 
                        ? 'bg-slate-900 text-white shadow-md' 
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                    onClick={() => updateSection('cornersDotOptions', { type: style })}
                  >
                    {style === undefined ? 'Nenhum' : style === 'dot' ? 'Ponto' : 'Quadrado'}
                  </Button>
                ))}
              </div>
            </div>
            <div className="border border-slate-100 p-4 rounded-xl bg-slate-50/30">
              <ColorControls section="cornersDotOptions" config={options.cornersDotOptions} label="Cor do Núcleo" />
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="background" className="bg-white border border-slate-100 rounded-xl overflow-hidden px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline py-5 group">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-amber-50 text-amber-600 group-hover:bg-amber-100 transition-colors">
                <Palette className="w-4 h-4" />
              </div>
              <span className="text-xs font-black uppercase tracking-widest text-slate-900">Opções de Fundo</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-6 space-y-6">
            <div className="border border-slate-100 p-4 rounded-xl bg-slate-50/30 space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-[11px] uppercase text-slate-900 font-extrabold tracking-widest">Tipo de cor</Label>
                  <Tabs 
                    value={options.backgroundOptions.colorType} 
                    onValueChange={(val) => updateSection('backgroundOptions', { colorType: val })}
                    className="bg-slate-100 p-1 rounded-lg"
                  >
                    <TabsList className="w-full bg-transparent">
                      <TabsTrigger value="single" className="flex-1 text-[10px] uppercase font-bold">Cor Única</TabsTrigger>
                      <TabsTrigger value="gradient" className="flex-1 text-[10px] uppercase font-bold">Gradiente de Cores</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>

                {options.backgroundOptions.colorType === 'single' ? (
                  <div className="space-y-2">
                    <Label className="text-[10px] uppercase text-slate-400 font-bold">Cor de fundo</Label>
                    <div className="flex gap-2">
                      <Input 
                        type="color" 
                        className="w-12 h-10 p-1 cursor-pointer" 
                        value={options.backgroundOptions.color}
                        onChange={(e) => updateSection('backgroundOptions', { color: e.target.value })}
                      />
                      <Input 
                        type="text" 
                        value={options.backgroundOptions.color}
                        onChange={(e) => updateSection('backgroundOptions', { color: e.target.value })}
                        className="flex-1 h-10 font-mono text-sm"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4 pt-2">
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase text-slate-400 font-bold">Tipo de gradiente</Label>
                      <Tabs 
                        value={options.backgroundOptions.gradient.type} 
                        onValueChange={(val) => updateGradient('backgroundOptions', { type: val })}
                        className="bg-white p-1 rounded-md border border-slate-200"
                      >
                        <TabsList className="w-full bg-transparent h-8">
                          <TabsTrigger value="linear" className="flex-1 text-[10px] uppercase">Linear</TabsTrigger>
                          <TabsTrigger value="radial" className="flex-1 text-[10px] uppercase">Radial</TabsTrigger>
                        </TabsList>
                      </Tabs>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase text-slate-400 font-bold">Gradiente de fundo</Label>
                      <div className="grid grid-cols-2 gap-4">
                        <Input 
                          type="color" 
                          value={options.backgroundOptions.gradient.colorStops[0].color}
                          onChange={(e) => {
                            const stops = [...options.backgroundOptions.gradient.colorStops];
                            stops[0].color = e.target.value;
                            updateGradient('backgroundOptions', { colorStops: stops });
                          }}
                          className="w-full h-10 p-1"
                        />
                        <Input 
                          type="color" 
                          value={options.backgroundOptions.gradient.colorStops[1].color}
                          onChange={(e) => {
                            const stops = [...options.backgroundOptions.gradient.colorStops];
                            stops[1].color = e.target.value;
                            updateGradient('backgroundOptions', { colorStops: stops });
                          }}
                          className="w-full h-10 p-1"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label className="text-[10px] uppercase text-slate-400 font-bold">Rotação</Label>
                        <span className="text-xs font-bold">{options.backgroundOptions.gradient.rotation}°</span>
                      </div>
                      <Input 
                        type="number" 
                        value={options.backgroundOptions.gradient.rotation}
                        onChange={(e) => updateGradient('backgroundOptions', { rotation: Number(e.target.value) })}
                        className="h-10 text-sm"
                      />
                    </div>
                  </div>
                )}
              </div>
              
              <div className="pt-4 border-t border-slate-100 space-y-4">
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase text-slate-400 font-bold">Número do Tipo (0 = Auto)</Label>
                  <Input 
                    type="number" 
                    min={0} 
                    max={40}
                    value={options.qrOptions.typeNumber}
                    onChange={(e) => updateSection('qrOptions', { typeNumber: Number(e.target.value) })}
                    className="h-9 bg-white border-slate-200 text-xs"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-[10px] uppercase text-slate-400 font-bold">Modo de Codificação</Label>
                  <Tabs 
                    value={options.qrOptions.mode} 
                    onValueChange={(val) => updateSection('qrOptions', { mode: val })}
                    className="bg-white p-1 rounded-md border border-slate-200"
                  >
                    <TabsList className="w-full bg-transparent h-8">
                      {(['Numeric', 'Alphanumeric', 'Byte', 'Kanji'] as const).map((m) => (
                        <TabsTrigger key={m} value={m} className="flex-1 text-[9px] uppercase px-0">
                          {m === 'Numeric' ? 'Num' : m === 'Alphanumeric' ? 'Alfa' : m === 'Byte' ? 'Byte' : 'Kanji'}
                        </TabsTrigger>
                      ))}
                    </TabsList>
                  </Tabs>
                </div>

                <div className="space-y-2">
                  <Label className="text-[10px] uppercase text-slate-400 font-bold">Nível de Correção de Erros</Label>
                  <Tabs 
                    value={options.qrOptions.errorCorrectionLevel} 
                    onValueChange={(val) => updateSection('qrOptions', { errorCorrectionLevel: val })}
                    className="bg-white p-1 rounded-md border border-slate-200"
                  >
                    <TabsList className="w-full bg-transparent h-8">
                      {(['L', 'M', 'Q', 'H'] as const).map((l) => (
                        <TabsTrigger key={l} value={l} className="flex-1 text-[9px] uppercase">
                          {l}
                        </TabsTrigger>
                      ))}
                    </TabsList>
                  </Tabs>
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-start">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={exportAsJSON}
                className="h-8 px-3 flex gap-2 text-[9px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all border border-transparent hover:border-slate-100"
              >
                <FileJson className="w-3.5 h-3.5" />
                Opções de exportação como JSON
              </Button>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="image-options" className="bg-white border border-slate-100 rounded-xl overflow-hidden px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline py-5 group">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-blue-50 text-blue-600 group-hover:bg-blue-100 transition-colors">
                <ImageIcon className="w-4 h-4" />
              </div>
              <span className="text-xs font-black uppercase tracking-widest text-slate-900">Opções de Imagem</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-6 space-y-6">
            <div className="border border-slate-100 p-4 rounded-xl bg-slate-50/30 space-y-6">
              <div className="flex items-center justify-between">
                <Label className="text-[10px] uppercase text-slate-400 font-bold">Ocultar pontos de fundo</Label>
                <Button
                  size="xs"
                  variant={options.imageOptions.hideBackgroundDots ? 'default' : 'outline'}
                  onClick={() => updateSection('imageOptions', { hideBackgroundDots: !options.imageOptions.hideBackgroundDots })}
                  className="h-7 w-12 text-[8px] font-bold"
                >
                  {options.imageOptions.hideBackgroundDots ? 'SIM' : 'NÃO'}
                </Button>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] uppercase text-slate-400 font-bold">Tamanho da Imagem</Label>
                <Input 
                  type="number" 
                  step="0.1" 
                  min="0" 
                  max="1"
                  value={options.imageOptions.imageSize}
                  onChange={(e) => updateSection('imageOptions', { imageSize: Number(e.target.value) })}
                  className="h-10 text-sm"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] uppercase text-slate-400 font-bold">Margem</Label>
                <Input 
                  type="number" 
                  value={options.imageOptions.margin}
                  onChange={(e) => updateSection('imageOptions', { margin: Number(e.target.value) })}
                  className="h-10 text-sm"
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <div className="flex justify-center pt-8 gap-4">
        {user && (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleSave}
            disabled={isSaving}
            className="flex gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-emerald-600 border-emerald-200 hover:bg-emerald-50 transition-all"
          >
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Salvar Configuração
          </Button>
        )}
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={exportAsJSON}
          className="flex gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 hover:text-slate-900 transition-all"
        >
          <FileJson className="w-4 h-4" />
          Exportar (.json)
        </Button>
      </div>

      {user && (
        <div className="mt-8 pt-8 border-t border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-slate-400" />
              <h4 className="text-[11px] font-black uppercase tracking-widest text-slate-900">Configurações Salvas</h4>
            </div>
            {isLoadingConfigs && <Loader2 className="w-3 h-3 animate-spin text-slate-400" />}
          </div>
          
          <div className="space-y-2">
            <div className="flex gap-2 mb-4">
              <Input 
                value={configName} 
                onChange={(e) => setConfigName(e.target.value)} 
                placeholder="Nome da estilização"
                className="h-9 text-xs bg-slate-50 border-slate-200"
              />
            </div>
            
            {savedConfigs.length === 0 ? (
              <p className="text-[10px] text-slate-400 italic font-bold">Nenhuma configuração salva ainda.</p>
            ) : (
              <div className="grid grid-cols-1 gap-2">
                {savedConfigs.map((config) => (
                  <div 
                    key={config.id} 
                    className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-xl hover:border-emerald-500 transition-all cursor-pointer group"
                    onClick={() => {
                      setOptions(config.config);
                      toast.success(`Estilo "${config.name}" aplicado!`);
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-emerald-500" />
                      <div>
                        <p className="text-xs font-black text-slate-900">{config.name}</p>
                        <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">
                          {config.createdAt?.toDate ? new Date(config.createdAt.toDate()).toLocaleDateString() : 'Recent'}
                        </p>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-7 w-7 opacity-0 group-hover:opacity-100 text-slate-400 hover:text-rose-500 transition-all"
                      onClick={(e) => handleDeleteConfig(e, config.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
