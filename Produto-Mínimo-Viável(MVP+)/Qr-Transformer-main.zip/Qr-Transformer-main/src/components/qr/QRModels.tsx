import React, { useState, useEffect } from 'react';
import { PREDEFINED_TEMPLATES, QRTemplate } from '../../constants/qrTemplates';
import { QRState } from '../../types/qr';
import { getPublicTemplates, savePublicTemplate } from '../../services/qrService';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/button';
import { toast } from 'sonner';
import { 
  Plus, 
  Flame, 
  Users, 
  Sparkles, 
  Check, 
  Layers,
  Search,
  Loader2,
  Share2
} from 'lucide-react';
import { Input } from '../ui/input';

interface QRModelsProps {
  currentOptions: QRState;
  setOptions: React.Dispatch<React.SetStateAction<QRState>>;
}

export const QRModels: React.FC<QRModelsProps> = ({ currentOptions, setOptions }) => {
  const { user, profile } = useAuth();
  const [publicTemplates, setPublicTemplates] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSharing, setIsSharing] = useState(false);
  const [activeTab, setActiveTab] = useState<'featured' | 'community'>('featured');

  useEffect(() => {
    loadPublicTemplates();
  }, []);

  const loadPublicTemplates = async () => {
    setIsLoading(true);
    try {
      const templates = await getPublicTemplates();
      setPublicTemplates(templates);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const applyTemplate = (config: any) => {
    // Preserve data and dimensions, update styling
    setOptions(prev => ({
      ...prev,
      ...config,
      data: prev.data,
      width: prev.width,
      height: prev.height,
    }));
    toast.success("Modelo aplicado com sucesso!");
  };

  const handleShareCurrent = async () => {
    if (!user) {
      toast.error("Você precisa estar logado para compartilhar modelos.");
      return;
    }

    const name = window.prompt("Dê um nome ao seu modelo:");
    if (!name) return;

    setIsSharing(true);
    try {
      await savePublicTemplate(
        user.uid,
        profile?.displayName || user.email?.split('@')[0] || 'Anônimo',
        name,
        currentOptions
      );
      toast.success("Modelo compartilhado com a comunidade!");
      loadPublicTemplates();
    } catch (error) {
      toast.error("Erro ao compartilhar modelo.");
    } finally {
      setIsSharing(false);
    }
  };

  const filteredPredefined = PREDEFINED_TEMPLATES.filter(t => 
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    t.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredPublic = publicTemplates.filter(t => 
    t.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-6">
        <div className="space-y-1">
          <h3 className="text-2xl font-black uppercase tracking-tighter text-slate-900">Modelos de QR</h3>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Inspirações e criações da comunidade</p>
        </div>
        
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Buscar modelos..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 h-10 w-full sm:w-64 bg-slate-50 border-slate-200 text-xs font-bold"
            />
          </div>
          <Button 
            onClick={handleShareCurrent} 
            disabled={isSharing}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-black uppercase tracking-widest text-[10px] h-10 gap-2"
          >
            {isSharing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Share2 className="w-4 h-4" />}
            <span className="hidden sm:inline">Compartilhar Meu</span>
          </Button>
        </div>
      </div>

      <div className="flex gap-4">
        <button 
          onClick={() => setActiveTab('featured')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all outline-none focus-visible:ring-2 focus-visible:ring-slate-900 focus-visible:ring-offset-2 ${
            activeTab === 'featured' 
              ? 'bg-slate-900 text-white shadow-lg shadow-slate-200' 
              : 'bg-white text-slate-400 hover:text-slate-900'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          Destaques
        </button>
        <button 
          onClick={() => setActiveTab('community')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all outline-none focus-visible:ring-2 focus-visible:ring-slate-900 focus-visible:ring-offset-2 ${
            activeTab === 'community' 
              ? 'bg-slate-900 text-white shadow-lg shadow-slate-200' 
              : 'bg-white text-slate-400 hover:text-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          Comunidade
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {activeTab === 'featured' ? (
          filteredPredefined.map((template) => (
            <div 
              key={template.id}
              role="button"
              tabIndex={0}
              aria-label={`Aplicar modelo ${template.name}: ${template.description}`}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  applyTemplate(template.config);
                }
              }}
              className="group relative bg-white border border-slate-200 rounded-2xl overflow-hidden hover:border-slate-900 transition-all cursor-pointer shadow-sm hover:shadow-xl hover:-translate-y-1 focus-visible:ring-2 focus-visible:ring-slate-900 focus-visible:ring-offset-2 outline-none"
              onClick={() => applyTemplate(template.config)}
            >
              <div className="aspect-video bg-slate-50 flex items-center justify-center p-8 overflow-hidden">
                 {/* Visual indicator of the template colors */}
                 <div className="flex gap-2">
                    <div className="w-8 h-8 rounded-full border-2 border-white shadow-sm" style={{ backgroundColor: (template.config.dotsOptions as any)?.color || (template.config.dotsOptions as any)?.gradient?.colorStops[0]?.color || '#000' }} />
                    <div className="w-8 h-8 rounded-full border-2 border-white shadow-sm -ml-4" style={{ backgroundColor: (template.config.cornersSquareOptions as any)?.color || (template.config.cornersSquareOptions as any)?.gradient?.colorStops[0]?.color || '#000' }} />
                    <div className="w-8 h-8 rounded-full border-2 border-white shadow-sm -ml-4" style={{ backgroundColor: (template.config.backgroundOptions as any)?.color || '#fff' }} />
                 </div>
                 <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/5 transition-colors" />
              </div>
              <div className="p-5 border-t border-slate-100 bg-white">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-black text-slate-900 uppercase tracking-tighter">{template.name}</h4>
                  <div className="p-1 bg-amber-50 rounded">
                    <Sparkles className="w-3 h-3 text-amber-600" />
                  </div>
                </div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-relaxed line-clamp-2">
                  {template.description}
                </p>
              </div>
            </div>
          ))
        ) : (
          isLoading ? (
            <div className="col-span-full py-20 flex flex-col items-center justify-center gap-4">
              <Loader2 className="w-8 h-8 text-slate-200 animate-spin" />
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-300">Sincronizando Galeria...</p>
            </div>
          ) : (
            filteredPublic.length === 0 ? (
              <div className="col-span-full py-20 flex flex-col items-center justify-center text-center space-y-4">
                <div className="p-4 bg-slate-50 rounded-full">
                   <Users className="w-8 h-8 text-slate-200" />
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Ninguém compartilhou nada ainda.</p>
                  <p className="text-[9px] font-bold text-slate-300 uppercase tracking-widest italic">Seja o primeiro a deixar sua marca!</p>
                </div>
              </div>
            ) : (
              filteredPublic.map((template) => (
                <div 
                  key={template.id}
                  role="button"
                  tabIndex={0}
                  aria-label={`Aplicar modelo da comunidade ${template.name} por ${template.userName}`}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      applyTemplate(template.config);
                    }
                  }}
                  className="group relative bg-white border border-slate-200 rounded-2xl overflow-hidden hover:border-emerald-500 transition-all cursor-pointer shadow-sm hover:shadow-xl hover:-translate-y-1 focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 outline-none"
                  onClick={() => applyTemplate(template.config)}
                >
                  <div className="aspect-video bg-emerald-50/30 flex items-center justify-center p-8 overflow-hidden">
                    <Layers className="w-12 h-12 text-emerald-100 group-hover:scale-110 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-emerald-900/0 group-hover:bg-emerald-900/5 transition-colors" />
                  </div>
                  <div className="p-5 border-t border-slate-100 bg-white">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="font-black text-slate-900 uppercase tracking-tighter truncate max-w-[150px]">{template.name}</h4>
                      <div className="flex items-center gap-1">
                        <Flame className="w-3 h-3 text-orange-500" />
                        <span className="text-[10px] font-black text-orange-500">{template.likes || 0}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest truncate">
                        Por {template.userName}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            )
          )
        )}
      </div>

      <div className="p-8 rounded-2xl bg-slate-900 text-white overflow-hidden relative group">
         <div className="absolute right-0 top-0 w-64 h-64 bg-emerald-500 blur-[100px] opacity-20 -mr-32 -mt-32" />
         <div className="relative z-10 space-y-4">
            <h5 className="text-xl font-black uppercase tracking-tighter">Crie algo épico</h5>
            <p className="text-sm text-slate-300 font-medium max-w-md">Use as ferramentas do Studio para personalizar cada pixel do seu QR Code e depois compartilhe com o mundo.</p>
            <div className="flex gap-4 items-center">
               <div className="flex -space-x-2">
                 {[1,2,3,4].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-slate-900 bg-slate-800 flex items-center justify-center">
                       <Plus className="w-3 h-3 text-slate-500" />
                    </div>
                 ))}
               </div>
               <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Milhares de combinações possíveis</span>
            </div>
         </div>
      </div>
    </div>
  );
};
