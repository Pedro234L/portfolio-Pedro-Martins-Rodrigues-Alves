import React from 'react';
import { motion } from 'motion/react';

export const Hero: React.FC = () => {
  return (
    <div className="relative w-full py-24 px-6 flex flex-col items-center justify-center text-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-slate-200/20 via-transparent to-transparent pointer-events-none" />
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10"
      >
        <h1 className="text-6xl md:text-8xl font-black mb-6 tracking-tighter leading-none text-slate-900 uppercase">
          Precision <br />
          <span className="text-emerald-600 italic">Identity.</span>
        </h1>
        <p className="text-lg md:text-xl text-slate-600 max-w-xl mx-auto font-semibold tracking-tight">
          High-performance QR generation designed for maximum accessibility and visual clarity.
        </p>
      </motion.div>
    </div>
  );
};
