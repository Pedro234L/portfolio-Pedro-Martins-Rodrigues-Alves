import React from 'react';
import { QrCode, LogIn, LogOut, ShieldCheck, User as UserIcon, Eye } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useColorBlind, ColorBlindMode } from '../../context/ColorBlindContext';
import { Button } from '../ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';

export const Navbar: React.FC = () => {
  const { user, profile, isAdmin, login, logout } = useAuth();
  const { mode: colorMode, setMode: setColorMode } = useColorBlind();

  const colorBlindOptions: { label: string, value: ColorBlindMode }[] = [
    { label: 'Desativado', value: 'none' },
    { label: 'Protanopia (Vermelho)', value: 'protanopia' },
    { label: 'Deuteranopia (Verde)', value: 'deuteranopia' },
    { label: 'Tritanopia (Azul)', value: 'tritanopia' },
  ];

  return (
    <nav role="navigation" aria-label="Main Navigation" className="bg-white/80 backdrop-blur-md h-20 flex items-center px-8 sticky top-4 z-50 mx-4 rounded-xl border border-slate-200 shadow-sm">
      <div className="flex items-center gap-3">
        <div className="bg-slate-900 p-2 rounded-lg">
          <QrCode className="w-7 h-7 text-white" aria-hidden="true" />
        </div>
        <span className="text-2xl font-black tracking-tighter text-slate-900">
          QR <span className="text-emerald-600">TRANSFORMER</span>
        </span>
      </div>
      
      <div className="ml-8 hidden lg:flex gap-6 text-[11px] font-extrabold uppercase tracking-widest text-slate-500">
        <a href="#main-content" className="sr-only focus:not-sr-only focus:absolute focus:top-24 focus:left-8 bg-slate-900 text-white p-4 rounded-xl font-bold focus:ring-4 focus:ring-slate-900/20 outline-none">Pular para o conteúdo</a>
        <a href="#" className="hover:text-slate-900 transition-all focus-visible:text-slate-900 outline-none">Studio</a>
        <a href="#" className="hover:text-slate-900 transition-all focus-visible:text-slate-900 outline-none">Vault</a>
        {isAdmin && (
          <a href="#admin" className="text-emerald-600 hover:text-emerald-700 flex items-center gap-1 focus-visible:underline outline-none">
            <ShieldCheck className="w-3 h-3" />
            Admin
          </a>
        )}
      </div>

      <div className="ml-auto flex items-center gap-4">
        <DropdownMenu>
          <DropdownMenuTrigger className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-100 transition-all outline-none cursor-pointer group">
            <Eye className={`w-5 h-5 ${colorMode !== 'none' ? 'text-emerald-600' : 'text-slate-400'}`} />
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 group-hover:text-slate-900 hidden sm:block">Acessibilidade</span>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 mt-2">
            <DropdownMenuGroup>
              <DropdownMenuLabel>Modo Daltonismo</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {colorBlindOptions.map((opt) => (
                <DropdownMenuItem 
                  key={opt.value} 
                  onClick={() => setColorMode(opt.value)}
                  className={`cursor-pointer ${colorMode === opt.value ? 'bg-slate-100 font-bold' : ''}`}
                >
                  {opt.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>

        {!user ? (
          <Button 
            onClick={login}
            variant="default"
            size="sm"
            className="bg-slate-900 text-white flex gap-2 font-bold uppercase tracking-wider text-[10px]"
          >
            <LogIn className="w-4 h-4" />
            Login Google
          </Button>
        ) : (
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-2 hover:opacity-80 transition-all outline-none cursor-pointer">
              <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 overflow-hidden flex items-center justify-center">
                {profile?.photoURL ? (
                  <img src={profile.photoURL} alt={profile.displayName || 'User'} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                ) : (
                  <UserIcon className="w-4 h-4 text-slate-400" />
                )}
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-900 truncate max-w-[100px]">
                  {profile?.displayName || 'Usuário'}
                </p>
                <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">
                  {profile?.role || 'Visitante'}
                </p>
              </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 mt-2">
              <DropdownMenuGroup>
                <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer gap-2">
                  <UserIcon className="w-4 h-4" /> Perfil
                </DropdownMenuItem>
                {isAdmin && (
                  <DropdownMenuItem className="cursor-pointer gap-2 text-emerald-600 focus:text-emerald-600">
                    <ShieldCheck className="w-4 h-4" /> Administração
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} className="cursor-pointer gap-2 text-rose-600 focus:text-rose-600">
                  <LogOut className="w-4 h-4" /> Sair
                </DropdownMenuItem>
              </DropdownMenuGroup>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
    </nav>
  );
};
