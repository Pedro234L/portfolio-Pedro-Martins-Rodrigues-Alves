import React from 'react';

/**
 * SVG Filters for simulating color blindness.
 * Matrices based on common scientific models (e.g. Machado et al.)
 */
export const ColorBlindFilters: React.FC = () => {
  return (
    <svg style={{ position: 'absolute', height: 0, width: 0, overflow: 'hidden' }} aria-hidden="true">
      <defs>
        {/* Protanopia: Red deficiency */}
        <filter id="protanopia">
          <feColorMatrix
            type="matrix"
            values="0.567, 0.433, 0,     0, 0
                    0.558, 0.442, 0,     0, 0
                    0,     0.242, 0.758, 0, 0
                    0,     0,     0,     1, 0"
          />
        </filter>

        {/* Deuteranopia: Green deficiency */}
        <filter id="deuteranopia">
          <feColorMatrix
            type="matrix"
            values="0.625, 0.375, 0,   0, 0
                    0.7,   0.3,   0,   0, 0
                    0,     0.3,   0.7, 0, 0
                    0,     0,     0,   1, 0"
          />
        </filter>

        {/* Tritanopia: Blue deficiency */}
        <filter id="tritanopia">
          <feColorMatrix
            type="matrix"
            values="0.95, 0.05,  0,     0, 0
                    0,    0.433, 0.567, 0, 0
                    0,    0.475, 0.525, 0, 0
                    0,    0,     0,     1, 0"
          />
        </filter>
      </defs>
    </svg>
  );
};
