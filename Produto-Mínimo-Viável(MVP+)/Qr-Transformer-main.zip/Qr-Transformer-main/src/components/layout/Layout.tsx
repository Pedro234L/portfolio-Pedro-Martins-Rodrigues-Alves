import React from 'react';
import { Navbar } from './Navbar';
import { Hero } from './Hero';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-[#f5f5f5]">
      <Navbar />
      <Hero />
      <main className="flex-1 container mx-auto py-12 px-4 md:px-6">
        {children}
      </main>
      <footer className="py-8 border-t bg-white text-center text-sm text-muted-foreground">
        <p>© {new Date().getFullYear()} QR Code Styling Clone. Built with React & Tailwind.</p>
      </footer>
    </div>
  );
};
