import React, { useState, useEffect, useRef } from 'react';
import { 
  ref, 
  uploadBytesResumable, 
  getDownloadURL, 
  listAll, 
  deleteObject,
  FullMetadata,
  getMetadata
} from 'firebase/storage';
import { storage } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { 
  CloudUpload, 
  FileImage, 
  Trash2, 
  Loader2, 
  ExternalLink, 
  CheckCircle2, 
  AlertCircle 
} from 'lucide-react';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { toast } from 'sonner';

interface StorageFile {
  name: string;
  url: string;
  ref: any;
  metadata?: FullMetadata;
}

export const StorageManager: React.FC = () => {
  const { user, isAdmin } = useAuth();
  const [files, setFiles] = useState<StorageFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [loading, setLoading] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchFiles = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const storageRef = ref(storage, 'assets/');
      const result = await listAll(storageRef);
      
      const fileData = await Promise.all(
        result.items.map(async (item) => {
          const url = await getDownloadURL(item);
          const metadata = await getMetadata(item);
          return {
            name: item.name,
            url,
            ref: item,
            metadata
          };
        })
      );
      
      setFiles(fileData.sort((a, b) => 
        (b.metadata?.updated ? new Date(b.metadata.updated).getTime() : 0) - 
        (a.metadata?.updated ? new Date(a.metadata.updated).getTime() : 0)
      ));
    } catch (error) {
      console.error("Error fetching files:", error);
      toast.error("Erro ao carregar arquivos");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFiles();
  }, [user]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    // Security check: only images
    if (!file.type.startsWith('image/')) {
      toast.error("Apenas imagens são permitidas");
      return;
    }

    setUploading(true);
    setProgress(0);

    const storageRef = ref(storage, `assets/${Date.now()}_${file.name}`);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const pct = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        setProgress(pct);
      },
      (error) => {
        console.error("Upload failed:", error);
        toast.error("Erro no upload");
        setUploading(false);
      },
      async () => {
        toast.success("Arquivo enviado com sucesso!");
        setUploading(false);
        setProgress(0);
        fetchFiles();
      }
    );
  };

  const handleDelete = async (fileRef: any) => {
    if (!window.confirm("Deseja realmente excluir este arquivo?")) return;

    try {
      await deleteObject(fileRef);
      toast.success("Arquivo excluído");
      fetchFiles();
    } catch (error) {
      console.error("Delete failed:", error);
      toast.error("Erro ao excluir arquivo");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("URL copiada!");
  };

  if (!isAdmin) return null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h3 className="text-xl font-black uppercase tracking-tighter text-slate-900">Gestor de Arquivos Cloud</h3>
          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mt-1">Imagens para logotipos e ativos do sistema</p>
        </div>
        
        <div className="flex flex-col gap-2">
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleUpload} 
            className="hidden" 
            accept="image/*"
          />
          <Button 
            onClick={() => fileInputRef.current?.click()} 
            disabled={uploading}
            className="bg-slate-900 hover:bg-slate-800 text-white flex gap-2 font-black uppercase tracking-widest text-[10px] px-6"
          >
            {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CloudUpload className="w-4 h-4" />}
            {uploading ? `Enviando ${Math.round(progress)}%` : 'Novo Arquivo'}
          </Button>
          {uploading && <Progress value={progress} className="h-1 bg-slate-100" />}
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center p-20">
          <Loader2 className="w-10 h-10 text-slate-300 animate-spin" />
        </div>
      ) : files.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-20 bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl text-slate-400 space-y-4">
          <FileImage className="w-12 h-12 opacity-20" />
          <p className="font-bold uppercase tracking-widest text-[10px]">Nenhuma imagem encontrada</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {files.map((file) => (
            <div key={file.name} className="group bg-white border border-slate-200 rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-500 hover:-translate-y-1">
              <div className="aspect-square bg-slate-50 relative overflow-hidden flex items-center justify-center">
                <img 
                  src={file.url} 
                  alt={file.name} 
                  className="w-full h-full object-contain p-4 group-hover:scale-110 transition-transform duration-700" 
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <Button 
                    size="icon" 
                    variant="secondary" 
                    onClick={() => copyToClipboard(file.url)}
                    className="h-8 w-8 rounded-full"
                    title="Copiar URL"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                  <Button 
                    size="icon" 
                    variant="destructive" 
                    onClick={() => handleDelete(file.ref)}
                    className="h-8 w-8 rounded-full bg-rose-500 hover:bg-rose-600"
                    title="Excluir"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="p-4 space-y-1">
                <p className="text-[10px] font-black text-slate-900 uppercase truncate" title={file.name}>
                  {file.name.split('_').pop()}
                </p>
                <div className="flex items-center justify-between text-[8px] font-bold text-slate-400 uppercase tracking-widest">
                  <span>{(file.metadata?.size || 0 / 1024).toFixed(1)} KB</span>
                  <span>{new Date(file.metadata?.updated || '').toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
