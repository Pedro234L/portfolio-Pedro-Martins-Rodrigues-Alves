import React, { useEffect, useState } from 'react';
import { collection, query, getDocs, orderBy, limit } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { ShieldAlert, Users, Settings, Database, Activity, FileImage, LayoutDashboard } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';
import { StorageManager } from './StorageManager';

export const AdminDashboard: React.FC = () => {
  const { isAdmin } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [stats, setStats] = useState({ totalUsers: 0, totalConfigs: 0 });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (!isAdmin) return;

    const fetchData = async () => {
      try {
        const usersSnap = await getDocs(query(collection(db, 'users'), orderBy('lastLogin', 'desc'), limit(10)));
        const allUsersSnap = await getDocs(collection(db, 'users'));
        const configsSnap = await getDocs(collection(db, 'qrConfigs'));

        setUsers(usersSnap.docs.map(d => ({ id: d.id, ...d.data() })));
        setStats({
          totalUsers: allUsersSnap.size,
          totalConfigs: configsSnap.size
        });
      } catch (error) {
        console.error("Error fetching admin data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [isAdmin]);

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center p-20 text-center space-y-4">
        <ShieldAlert className="w-16 h-16 text-rose-500 animate-pulse" />
        <h2 className="text-2xl font-black uppercase tracking-tighter text-slate-900">Acesso Restrito</h2>
        <p className="text-slate-500 max-w-md">Você não possui privilégios de administrador para acessar este ambiente.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700" id="admin">
      <div className="flex items-center gap-4">
        <div className="bg-emerald-600 p-3 rounded-2xl shadow-lg shadow-emerald-500/20">
          <ShieldAlert className="w-8 h-8 text-white" />
        </div>
        <div>
          <h2 className="text-3xl font-black uppercase tracking-tighter text-slate-900 leading-none">Painel Administrativo</h2>
          <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-2">Central de Operações do Sistema</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
        <TabsList className="bg-white border border-slate-200 p-1 rounded-xl h-12 shadow-sm">
          <TabsTrigger value="overview" className="flex gap-2 items-center px-6 text-[10px] font-black uppercase tracking-widest data-[state=active]:bg-slate-900 data-[state=active]:text-white transition-all">
            <LayoutDashboard className="w-4 h-4" />
            Visão Geral
          </TabsTrigger>
          <TabsTrigger value="storage" className="flex gap-2 items-center px-6 text-[10px] font-black uppercase tracking-widest data-[state=active]:bg-slate-900 data-[state=active]:text-white transition-all">
            <FileImage className="w-4 h-4" />
            Galeria de Arquivos
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex gap-2 items-center px-6 text-[10px] font-black uppercase tracking-widest data-[state=active]:bg-slate-900 data-[state=active]:text-white transition-all">
            <Settings className="w-4 h-4" />
            Configurações
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-8 animate-in fade-in duration-500">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border-slate-200 shadow-sm overflow-hidden">
              <div className="h-1 bg-emerald-500" />
              <CardContent className="pt-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Total Usuários</p>
                    <h4 className="text-4xl font-black text-slate-900 mt-1">{stats.totalUsers}</h4>
                  </div>
                  <Users className="w-6 h-6 text-slate-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200 shadow-sm overflow-hidden">
              <div className="h-1 bg-blue-500" />
              <CardContent className="pt-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Configurações</p>
                    <h4 className="text-4xl font-black text-slate-900 mt-1">{stats.totalConfigs}</h4>
                  </div>
                  <Database className="w-6 h-6 text-slate-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200 shadow-sm overflow-hidden">
              <div className="h-1 bg-amber-500" />
              <CardContent className="pt-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Status API</p>
                    <h4 className="text-xl font-black text-emerald-600 mt-2 uppercase">Operacional</h4>
                  </div>
                  <Activity className="w-6 h-6 text-slate-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200 shadow-sm overflow-hidden">
              <div className="h-1 bg-slate-900" />
              <CardContent className="pt-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Versão</p>
                    <h4 className="text-xl font-black text-slate-900 mt-2 uppercase tracking-tighter">v3.1-Stable</h4>
                  </div>
                  <Settings className="w-6 h-6 text-slate-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-black uppercase tracking-tighter text-slate-900">Acessos Recentes</h3>
                <Button variant="ghost" size="sm" className="text-[10px] font-bold uppercase tracking-widest">Ver Todos</Button>
              </div>
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-black uppercase tracking-widest text-slate-400">
                      <th className="px-6 py-4">Usuário</th>
                      <th className="px-6 py-4">Email</th>
                      <th className="px-6 py-4">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {users.map((u) => (
                      <tr key={u.id} className="text-sm hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4 flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-100 overflow-hidden">
                            {u.photoURL && <img src={u.photoURL} alt={u.displayName} className="w-full h-full object-cover" />}
                          </div>
                          <span className="font-bold text-slate-700">{u.displayName || 'Sem nome'}</span>
                        </td>
                        <td className="px-6 py-4 font-mono text-slate-500 text-xs">{u.email}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${u.role === 'admin' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                            {u.role}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-black uppercase tracking-tighter text-slate-900">Atividade do Sistema</h3>
              <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6">
                <div className="flex gap-4">
                  <div className="bg-emerald-50 p-2 rounded-lg h-fit">
                    <ShieldAlert className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900">Backup Automático Concluído</p>
                    <p className="text-[10px] text-slate-400 mt-1">Hoje às 04:30 AM</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-blue-50 p-2 rounded-lg h-fit">
                    <Database className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900">Sincronização Cloud Realizada</p>
                    <p className="text-[10px] text-slate-400 mt-1">Hoje às 02:15 AM</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="storage" className="animate-in fade-in duration-500">
          <StorageManager />
        </TabsContent>

        <TabsContent value="settings" className="p-20 text-center animate-in fade-in duration-500">
          <Settings className="w-12 h-12 text-slate-200 mx-auto" />
          <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px] mt-4">Configurações globais do sistema em breve.</p>
        </TabsContent>
      </Tabs>
    </div>
  );
};
