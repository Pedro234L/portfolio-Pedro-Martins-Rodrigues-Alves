import React, { createContext, useContext, useState, useEffect } from 'react';

export type ColorBlindMode = 'none' | 'protanopia' | 'deuteranopia' | 'tritanopia';

interface ColorBlindContextType {
  mode: ColorBlindMode;
  setMode: (mode: ColorBlindMode) => void;
}

const ColorBlindContext = createContext<ColorBlindContextType | undefined>(undefined);

export const ColorBlindProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [mode, setMode] = useState<ColorBlindMode>(() => {
    const saved = localStorage.getItem('color-blind-mode');
    return (saved as ColorBlindMode) || 'none';
  });

  useEffect(() => {
    localStorage.setItem('color-blind-mode', mode);
    // Apply filter class to body or html for global effect
    document.documentElement.setAttribute('data-color-blind', mode);
  }, [mode]);

  return (
    <ColorBlindContext.Provider value={{ mode, setMode }}>
      {children}
    </ColorBlindContext.Provider>
  );
};

export const useColorBlind = () => {
  const context = useContext(ColorBlindContext);
  if (!context) throw new Error('useColorBlind must be used within ColorBlindProvider');
  return context;
};
