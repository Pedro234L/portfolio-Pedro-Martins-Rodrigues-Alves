import { QRState } from '../types/qr';

export interface QRTemplate {
  id: string;
  name: string;
  description: string;
  config: Partial<QRState>;
  author?: string;
  isCustom?: boolean;
}

export const PREDEFINED_TEMPLATES: QRTemplate[] = [
  {
    id: 'neon-cyber',
    name: 'Cyber Neon',
    description: 'Design futurista com gradientes vibrantes em tons de roxo e azul.',
    config: {
      dotsOptions: {
        type: 'dots',
        colorType: 'gradient',
        gradient: {
          type: 'linear',
          rotation: 45,
          colorStops: [
            { offset: 0, color: '#8b5cf6' },
            { offset: 1, color: '#ec4899' },
          ],
        },
        color: '#8b5cf6',
      },
      cornersSquareOptions: {
        type: 'extra-rounded',
        colorType: 'single',
        gradient: { type: 'linear', rotation: 0, colorStops: [] },
        color: '#8b5cf6',
      },
      cornersDotOptions: {
        type: 'dot',
        colorType: 'single',
        gradient: { type: 'linear', rotation: 0, colorStops: [] },
        color: '#ec4899',
      },
    }
  },
  {
    id: 'emerald-eco',
    name: 'Emerald Eco',
    description: 'Minimalismo orgânico com tons de verde esmeralda e formas suaves.',
    config: {
      dotsOptions: {
        type: 'rounded',
        colorType: 'single',
        gradient: { type: 'linear', rotation: 0, colorStops: [] },
        color: '#10b981',
      },
      cornersSquareOptions: {
        type: 'dot',
        colorType: 'single',
        gradient: { type: 'linear', rotation: 0, colorStops: [] },
        color: '#065f46',
      },
      cornersDotOptions: {
        type: 'square',
        colorType: 'single',
        gradient: { type: 'linear', rotation: 0, colorStops: [] },
        color: '#10b981',
      },
      backgroundOptions: {
        colorType: 'single',
        gradient: { type: 'linear', rotation: 0, colorStops: [] },
        color: '#f0fdf4',
      }
    }
  },
  {
    id: 'royal-luxury',
    name: 'Royal Luxury',
    description: 'Elegância clássica com preto e dourado.',
    config: {
      dotsOptions: {
        type: 'classy',
        colorType: 'single',
        gradient: { type: 'linear', rotation: 0, colorStops: [] },
        color: '#000000',
      },
      cornersSquareOptions: {
        type: 'square',
        colorType: 'gradient',
        gradient: {
          type: 'linear',
          rotation: 90,
          colorStops: [
            { offset: 0, color: '#b45309' },
            { offset: 1, color: '#fbbf24' },
          ],
        },
        color: '#b45309',
      },
      cornersDotOptions: {
        type: 'square',
        colorType: 'single',
        gradient: { type: 'linear', rotation: 0, colorStops: [] },
        color: '#b45309',
      }
    }
  },
  {
    id: 'ocean-breeze',
    name: 'Ocean Breeze',
    description: 'Fresco e moderno com azuis profundos.',
    config: {
      dotsOptions: {
        type: 'classy-rounded',
        colorType: 'gradient',
        gradient: {
          type: 'linear',
          rotation: 0,
          colorStops: [
            { offset: 0, color: '#1e40af' },
            { offset: 1, color: '#60a5fa' },
          ],
        },
        color: '#1e40af',
      },
      cornersSquareOptions: {
        type: 'extra-rounded',
        colorType: 'single',
        color: '#1e40af',
        gradient: { type: 'linear', rotation: 0, colorStops: [] },
      },
      cornersDotOptions: {
        type: 'dot',
        colorType: 'single',
        color: '#60a5fa',
        gradient: { type: 'linear', rotation: 0, colorStops: [] },
      }
    }
  }
];
