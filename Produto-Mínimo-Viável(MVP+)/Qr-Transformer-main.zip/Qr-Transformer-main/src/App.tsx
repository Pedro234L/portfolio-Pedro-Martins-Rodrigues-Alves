import { useState, useEffect } from 'react';
import { Layout } from './components/layout/Layout';
import { QRControls } from './components/qr/QRControls';
import { QRPreview } from './components/qr/QRPreview';
import { QRModels } from './components/qr/QRModels';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { initialQRState, QRState } from './types/qr';
import { useAuth } from './context/AuthContext';
import { Toaster } from './components/ui/sonner';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './components/ui/tabs';
import { Sparkles, Palette, History } from 'lucide-react';

import { ColorBlindFilters } from './components/layout/ColorBlindFilters';

export default function App() {
  const [options, setOptions] = useState<QRState>(initialQRState);
  const [view, setView] = useState<'editor' | 'admin'>('editor');
  const { user, isAdmin, loading } = useAuth();

  useEffect(() => {
    if (!loading && !user && view === 'editor') {
      import('sonner').then(({ toast }) => {
        toast.info("Atenção", {
          description: "Faça login para salvar suas configurações de QR Code na nuvem.",
          duration: 5000,
        });
      });
    }
  }, [user, loading, view]);

  useEffect(() => {
    const handleHashChange = () => {
      if (window.location.hash === '#admin' && isAdmin) {
        setView('admin');
      } else {
        setView('editor');
        if (window.location.hash === '#admin' && !isAdmin) {
          window.location.hash = '';
        }
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Check on mount

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [isAdmin]);

  return (
    <Layout>
      {view === 'admin' ? (
        <AdminDashboard />
      ) : (
        <main id="main-content" role="main" aria-label="QR Code Transformation Workspace" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6 auto-rows-max">
          {/* Persistent Preview Section */}
          <section aria-label="Live QR Preview" className="lg:col-span-12 xl:col-span-4 row-span-1 lg:row-span-2 order-1 lg:order-2 lg:sticky lg:top-24 lg:self-start">
            <div className="bento-card h-full flex flex-col items-center justify-center relative overflow-hidden group">
              <div className="absolute top-0 left-0 w-full h-1 bg-slate-900" />
              <QRPreview options={options} />
            </div>

            {/* Metrics displayed under preview for context */}
            <div className="mt-6 bento-card bg-white border-slate-200 grid grid-cols-3 gap-2 py-4">
              <div className="text-center">
                <span className="text-[8px] font-bold uppercase tracking-widest text-slate-400">Densidade</span>
                <p className="text-sm font-black text-slate-900">{options.qrOptions.typeNumber || 'Auto'}</p>
              </div>
              <div className="text-center">
                <span className="text-[8px] font-bold uppercase tracking-widest text-slate-400">Entropia</span>
                <p className="text-sm font-black text-slate-900">{options.qrOptions.errorCorrectionLevel}</p>
              </div>
              <div className="text-center">
                <span className="text-[8px] font-bold uppercase tracking-widest text-slate-400">Modo</span>
                <p className="text-sm font-black text-emerald-600">{options.qrOptions.mode}</p>
              </div>
            </div>
          </section>

          {/* Main workspace with Tabs */}
          <section aria-label="Configuration Controls" className="lg:col-span-12 xl:col-span-8 order-2 lg:order-1">
            <Tabs defaultValue="studio" className="w-full space-y-6">
              <TabsList className="bg-white border border-slate-200 h-14 p-1 rounded-2xl w-full sm:w-auto shadow-sm">
                <TabsTrigger 
                  value="studio" 
                  className="px-8 h-full rounded-xl data-[state=active]:bg-slate-900 data-[state=active]:text-white data-[state=active]:shadow-lg gap-2 text-[11px] font-black uppercase tracking-widest flex items-center transition-all"
                >
                  <Palette className="w-4 h-4" />
                  Studio
                </TabsTrigger>
                <TabsTrigger 
                  value="models" 
                  className="px-8 h-full rounded-xl data-[state=active]:bg-slate-900 data-[state=active]:text-white data-[state=active]:shadow-lg gap-2 text-[11px] font-black uppercase tracking-widest flex items-center transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  Modelos de QR
                </TabsTrigger>
              </TabsList>

              <TabsContent value="studio" className="mt-0 focus-visible:outline-none animate-in fade-in zoom-in-95 duration-300">
                <div className="bento-card bg-white border-slate-200">
                  <QRControls options={options} setOptions={setOptions} />
                </div>
              </TabsContent>

              <TabsContent value="models" className="mt-0 focus-visible:outline-none animate-in fade-in zoom-in-95 duration-300">
                <div className="bento-card bg-white border-slate-200">
                  <QRModels currentOptions={options} setOptions={setOptions} />
                </div>
              </TabsContent>
            </Tabs>
          </section>
        </main>
      )}
      <Toaster position="bottom-right" />
      <ColorBlindFilters />
    </Layout>
  );
}
